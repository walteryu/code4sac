# Assessment
Personal ID
Assessment ID
Assessment Type
Assessment Score
Assessment Date

# Client Table
Clients Race
Clients Ethnicity
Clients Gender
Clients Veteran Status
Clients Discharge Status
Clients Date Created Date
Clients Date Updated
Birth_Date_d
Personal_Id_d

# Enrollment Screen
Personal ID
Enrollment Id
Household ID
Enrollments Project Id
Entry Screen Added Date
Entry Screen Housing Status
Entry Screen Length of Stay in Prior Living Situation
Entry Screen Times Homeless in the Past Three Years
Entry Screen Total Months Homeless in Past Three Years
Entry Screen Client Became Enrolled in PATH (Yes / No)
Entry Screen Reason not Enrolled
Entry Screen City
Entry Screen State
Entry Screen Zip Code
Entry Screen Chronic Homeless at Project Start
Entry Screen Residence Prior to Project Entry
Entry Screen Last Grade Completed

# Exit Screen
Personal ID
Enrollment Id
Exit Destination
Exit Reason
Project Exit Date

# Program Table
Program Id
Agency Id
Name
Availability Start Date
Availability End Date
Continuum Project
Project Type Code
Affiliated Project Ids
Affiliated with a Residential Project
Tracking Method
Target Population
Victim Service Provider
Housing Type
Added Date
Last Updated Date

# Service Table
Personal ID
Enrollment ID
Service ID
Delivery Type
Service Category
Start Date
End Date
